var dbConfig = require('../config/db'),
  arangojs = require('arangojs'),
  DB = new arangojs.Database({
    url: dbConfig.url
  });

DB.useDatabase(dbConfig.database);

DB.useBasicAuth(dbConfig.username, dbConfig.password);

// Collection to manage: Article
var Student = DB.collection('student');

exports.create = function (student) {	
    if (!student.name || !student.address||!student.city)
    return ;
    Student.save(student, { returnNew: true} );
};

exports.update = function (student) {
  if (!student._key) return;
  return Student.update(student._key,student);
};

exports.findAll = async function () {
  data= await Student.all();
  return data;
}

exports.delete=async function(key){
  return await Student.removeByKeys([key]);
}

exports.find=async function(key){
  data= await Student.firstExample({_key:key});
  return data;
}
