const express = require('express')
const arangojs = require("arangojs");
const db = new arangojs.Database();

const app = express()
const port = 3000
const path=require('path')

const student=require('./resources/student.js')


app.use(express.urlencoded({
extended:true
}))



app.use(express.json())

app.use(express.urlencoded({ extended: true }))


app.post('/create', function (req, res) {
  res.json(student.create(req.body));
})


app.post('/update',function(req,res){
   student.update(req.body).then(function(){
    res.json("Update Successful");
   },function(){
    res.json("Update Failure");
   });
});

app.get('/read',function(req,res){
  student.findAll().then(function(response){
    console.log(response._result);
     res.json(response._result);
  },function(error){
     res.json(error);
  });
});

app.get('/read/:id',function(req,res){
  student.find(req.params.id).then(function(response){
    console.log(response);
    res.json(response);
  },function(error){
    console.log(error.code);
    res.json(error.code);
  });
});

app.get('/delete/:id',function(req,res){
  student.delete(req.params.id).then(function(){
    res.json("Delete Successfull");
  },function(){
     res.json("Delete Failure");
  });
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
