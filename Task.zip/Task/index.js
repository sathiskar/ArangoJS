const express = require('express');
const route=require('./route/route');
const config=require('./config/config');
const bodyParser=require('body-parser');

//config
const port=config.port;


//server
const app = express();

//Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Routes
app.use(route);


app.listen(port, () => {
    console.log(`Server started on ${port}`);
});



