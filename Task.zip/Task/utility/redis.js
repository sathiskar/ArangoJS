const redis = require("redis");
const client = redis.createClient();
 
client.on("connected", function(error) {
    console.error("connected");
});

client.on("error", function(error) {
  console.error(error);
});
 


module.exports=client
