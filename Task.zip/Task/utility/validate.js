const { default: validator } = require('validator')
const userRegistration=function(values){
    try {
        if(values.mail==null||values.password==null||values.address==null)
        return {
            isValid:false,
            message:"Missing Parameter",
        };
        if(validator.isEmail(values.mail)&&validator.isAlphanumeric(values.password)&&validator.isAlpha(values.address)){
            return {
                isValid:true,
                message:"Validation Success",
            };
        }

        return{
            isValid:false,
            message:"Values Error",
        }

    } catch (error) {
        console.log(error);
        throw error;
    }
    
}

const userLogin=function(values){
    try {
        if(values.mail==null||values.password==null)
        return {
            isValid:false,
            message:"Missing Parameter",
        };
        if(validator.isEmail(values.mail)&&validator.isAlphanumeric(values.password)){
            return {
                isValid:true,
                message:"Validation Success",
            };
        }

        return{
            isValid:false,
            message:"Values Error",
        }

    } catch (error) {
        console.log(error);
        throw error;
    }
    
}

const student=function(values){
    try {
        console.log(values);
        if(values.id==null||values.name==null||values.std==null||values.address==null){
            return {
                isValid:false,
                message:"Missing Parameter",
            }
        }
        if(validator.isNumeric(values.id)||validator.isAlpha(values.name)&&validator.isNumeric(values.std)&&validator.isAlpha(values.address)){
            return {
                isValid:true,
                message:"Validation Success",
            }
        }
        return{
            isValid:false,
            message:"Values Error",
        }
    } catch (error) {
        console.log(error);
        throw error;
    }
}

const key=function(value){

    try {
        if(value==null){
            return {
                isValid:false,
                message:"Key Missing"
            }
        }
        if(validator.isNumeric(value)){
            return {
                isValid:true,
                message:"Validation Success"
            }
        }
        return{
            isValid:false,
            message:"Value Error"
        }
    } catch (error) {
        console.log(error);
        throw error;
    }

}

module.exports={
    userRegistration,
    userLogin,
    student,
    key
}