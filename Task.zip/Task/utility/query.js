const DB=require('../config/db');

const exec=async function(query){
    try {
        return await DB.query(query).then(function(response){
            return response;
        },function(err){
            throw err;
        });
    } catch (err) {
        console.log(error);
        throw err;
    }
};

module.exports=exec