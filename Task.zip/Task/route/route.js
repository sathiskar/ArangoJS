const { request } = require('express');
const express=require('express');
const { default: validator } = require('validator');
const student=require('../resource/student');
const user=require('../resource/user');
const route=express.Router();
const validate=require('../utility/validate');
const {authenticateToken}=require('../utility/jwt');
const client=require('../utility/redis');



function getCache(req,res,next){
    client.GET("students", function(err,obj) {
        if(!err&&obj!=null){
            res.json(JSON.parse(obj));
        }
        else{
            next();
        }
    }); 
}



route.get('/students',authenticateToken,getCache,(req, res) => {
    student.getAll().then(function(response){
        client.SET('students',JSON.stringify(response._result));
        res.json(response._result);
    },function(err){
         res.json(err);
    });
});

route.get('/students/:id',authenticateToken,(req, res) => {
    key=req.params.id;
    const {isValid,message}=validate.key(key);

    if(isValid){
        student.get(key).then(function(response){
            res.json(response);
        },function(err){
             res.json(err);
        });
    }
    else{
         res.json(message);
    }
});

route.post('/students',authenticateToken,(req, res) => {
    values=req.body;
    console.log(values);
    const {isValid,message}=validate.student(values);
    if(isValid){
        values._key=values.id;
        student.create(values).then(function(response){
            obj={
                code:200,
                data:response,
                message:'success'
            }
            res.json(obj);
        },function(err){
            obj={
                code:400,
                data:err,
                message:'fail',
            }
            res.json(obj);
        });
    }
    else{
        console.log(message);
        res.json({message});
    }
});



route.put('/students/:id',authenticateToken,(req,res)=>{
    values=req.body;
    values.id=req.params.id;
    const {isValid,message}=validate.student(values);
    if(isValid){
        student.update(values.id,values).then(function(response){
            obj={
                code:200,
                data:response,
                message:'success'
            }
            res.json(obj);
        },function(err){
            obj={
                code:400,
                data:err,
                message:'fail',
            }
            res.json(obj);
        });
    }
    else{
        console.log(message);
        res.json({message});
    }
});

route.delete('/students/:id',authenticateToken,(req,res)=>{
    key=req.params.id;
    const {isValid,message}=validate.key(key);
    if(isValid){
        student.remove(key).then(function(response){
            obj={
                code:200,
                data:response,
                message:'success'
            }
            res.json(obj);
        },function(err){
            obj={
                code:400,
                data:err,
                message:'fail',
            }
            res.json(obj);
        });
    }
    else{
         res.json({message});
    }
});

route.post('/register',(req, res) => {
    values=req.body;
    const {isValid,message}=validate.userRegistration(values);
    if(isValid){
        values._key=values.id;
        user.create(values).then(function(response){
            obj={
                code:200,
                data:response,
                message:'success'
            }
            res.json(obj);
        },function(err){
            obj={
                code:400,
                data:err,
                message:'fail',
            }
            res.json(obj);
        });
    }
    else{
        console.log(message);
        res.json({message});
    }
});

route.post('/login', (req, res) => {
    values=req.body;
    const {isValid,message}=validate.userLogin(values);
    if(isValid){
        values._key=values.id;
        user.login(values.mail,values.password).then(function(response){
            obj={
                code:200,
                token:response,
                message:'login successfull'
            }
            res.json(obj);
        },function(err){
            obj={
                code:400,
                data:err._result,
                message:'fail',
            }
            res.json(obj);
        });
    }
    else{
        console.log(message);
        res.json({message});
    }
});


module.exports=route