const dotenv=require('dotenv');
dotenv.config();
const config={
    logger:{
        level:process.env.LOG_LEVEL||'info',
        enabled:process.env.BOOLEAN?process.env.BOOLEAN.toLowerCase()==='true':false,
    },
    db:{
        host: process.env.host || 'http://127.0.0.1:8529', // The Default URL for a local server
        database: process.env.database||'mystudents',      // The Database Name
        user:process.env.user ||'root',                    //Database User Name
        password:process.env.password ||'password'         //Database Password
    },
    port:process.env.port||3000,
}

module.exports=config                                       //Export module