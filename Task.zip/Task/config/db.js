const config=require('./config');
const { default: arangojs } = require('arangojs');

//database
var DB = new arangojs.Database({
    url: config.db.host
  });

DB.useDatabase(config.db.database);

DB.useBasicAuth(config.db.user,config.db.password);

module.exports=DB