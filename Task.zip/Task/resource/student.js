const exec=require('../utility/query');

const create=async function(values){
    console.log("insert Student Details...");
    student={
        _key:values.id,
        name:values.name,
        address:values.address,
        std:values.std
    }
    query="INSERT "+JSON.stringify(student)+" INTO student";
    return await exec(query);
}

const getAll=async function(){
    console.log("request Student Details...");
    query="FOR students IN student RETURN students";
    return await exec(query);
}

const get=async function(_key){
    console.log("request Student Details...");
    query="FOR students IN student FILTER students.id=="+_key+" RETURN students.name";
    return await exec(query);
}

const update=async function(_key,values){
    console.log("Update Student Details");
    query="UPDATE '"+_key+"' WITH "+JSON.stringify(values)+" IN student";
    return await exec(query);
}

const remove=async function(_key){
    console.log("Remove Student Detail");
    query="REMOVE '"+_key+"' IN student";
    return await exec(query);
}

module.exports={
    create,
    getAll,
    update,
    remove,
    get
}