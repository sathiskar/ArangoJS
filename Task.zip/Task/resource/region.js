const exec=require('../utility/query');

const create=async function(values){
    console.log("insert Region Details...");
    query="INSERT "+JSON.stringify(student)+" INTO user";
    return await exec(query);
}

const getAll=async function(params) {
    console.log("get All User Region...");
}

