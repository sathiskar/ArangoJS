const { CollectionType } = require('arangojs/lib/cjs/collection');
const { json } = require('express');
const exec=require('../utility/query');
const token=require('../utility/jwt');

const create=async function(values){
    user={
        _key:values.mail,
        name:values.name,
        address:values.address,
        password:values.password,
        isAdmin:values.isAdmin,
    }
    query="INSERT "+JSON.stringify(user)+" INTO user";
    return await exec(query);
}

const login=async function(mail,password){
    query="FOR u IN user FILTER u._key == '"+mail+"' and u.password=='"+password+"' RETURN u";
    user=await exec(query);
    user=user._result;
    console.log(user)
    if(user.length===1){
        payload={
            name:user[0].name,
            mail:user[0]._key,
            isAdmin:user[0].isAdmin,
        }
        console.log(payload);
        return token.generate(payload);
    }
    throw error;
}

const getUser=async function(region) {
    query="FOR user IN user FOR region IN region FILTER user._key == region._key and region.region=='"+region+"' RETURN merge(user,region)";
    user=await exec(query);
    return user;
}


module.exports={
    create,
    login,
    getUser,
}


