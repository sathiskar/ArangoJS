const { CollectionType } = require('arangojs/lib/cjs/collection');
const { json } = require('express');
const exec=require('../utility/query');
const token=require('../utility/jwt');

const create=async function(values){
    user={
        _key:values.mail,
        name:values.name,
        address:values.address,
        password:values.password,
    }
    query="INSERT "+JSON.stringify(user)+" INTO user";
    return await exec(query);
}

const login=async function(mail,password){
    query="FOR u IN user FILTER u._key == '"+mail+"' and u.password=='"+password+"' RETURN u";
    user=await exec(query);
    if(user.length){
        payload={
            name:user[0].name,
            mail:user[0]._key,
        }
        return token.generate(payload);
    }
    throw error;
}

module.exports={
    create,
    login
}


